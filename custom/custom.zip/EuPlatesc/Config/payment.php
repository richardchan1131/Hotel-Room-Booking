<?php
return [
    'gateways' => [
        'euplatesc' => '',
    ],
];
