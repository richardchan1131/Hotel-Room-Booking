<?php

namespace Custom\Hotel\App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Modules\FrontendController;

class VendorRoomController extends Controller
{
    public function index()
    {
        
    }

    public function edit()
    {
        dd(1);
    }
}
