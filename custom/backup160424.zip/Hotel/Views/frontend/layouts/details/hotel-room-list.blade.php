<div class="room-available pt-30 hotel_rooms_form">
    <div class="hotel_list_rooms" :class="{ 'loading': onLoadAvailability }">
        <div class="row">
            <div class="col-12">
                <div class="start_room_sticky"></div>
                <div class="room-item border-light rounded-4 px-30 py-30 sm:px-20 sm:py-20" :class="{ 'mt-20': index }"
                    v-for="(room,index) in rooms">
                    <h3 class="text-18 fw-500 mb-15">@{{ room.title }}</h3>
                    <div class="roomGrid">
                        <div class="roomGrid__header">
                            <div>{{ __('Room Type') }}</div>
                            <div>{{ __('Benefits') }}</div>
                            <div>{{ __('Select Rooms') }}</div>
                        </div>
                        <div class="roomGrid__grid">
                            <div>
                                <div class="ratio ratio-1:1" @click="showGallery($event,room.id,room.gallery)">
                                    <img :src="room.image" alt="image" class="img-ratio rounded-4">
                                    <div class="count-gallery"
                                        v-if="typeof room.gallery !='undefined' && room.gallery && room.gallery.length > 1">
                                        <i class="fa fa-picture-o"></i>
                                        @{{ room.gallery.length }}
                                    </div>
                                </div>

                                <a href="javascript:void(0)" class="d-block text-15 fw-500 underline text-blue-1 mt-15"
                                    @click="showGallery($event,room.id,room.gallery)">{{ __('Show Room Information') }}</a>
                                <div class="modal" :id="'modal_room_' + room.id" tabindex="-1" role="dialog">
                                    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">@{{ room.title }}</h5>
                                                <span class="c-pointer" data-dismiss="modal" aria-label="Close">
                                                    <i class="input-icon field-icon fa">
                                                        <img src="{{ asset('images/ico_close.svg') }}" alt="close">
                                                    </i>
                                                </span>
                                            </div>
                                            <div class="modal-body">
                                                <div class="fotorama" data-nav="thumbs" data-width="100%"
                                                    data-auto="false" data-allowfullscreen="true">
                                                    <a v-for="g in room.gallery" :href="g.large"></a>
                                                </div>
                                                <div class="list-attributes">
                                                    <div class="attribute-item" v-for="term in room.terms">
                                                        <h4 class="title">@{{ term.parent.title }}</h4>
                                                        <ul class="d-flex justify-content-between flex-wrap"
                                                            v-if="term.child">
                                                            <li v-for="term_child in term.child">
                                                                <i class="input-icon field-icon"
                                                                    v-bind:class="term_child.icon" data-toggle="tooltip"
                                                                    data-placement="top" :title="term_child.title"></i>
                                                                @{{ term_child.title }}
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="roomGrid__content">
                                    <div class="room-type-item">
                                        <div class="room-attribute room-meta d-flex">
                                            <div class="item col-auto" v-if="room.size_html">
                                                <div class="tooltip -top h-50">
                                                    <div class="tooltip__text">
                                                        <i class="input-icon field-icon icofont-ruler-compass-alt"></i>
                                                        <span v-html="room.size_html"></span>
                                                    </div>
                                                    <div class="tooltip__content">{{ __('Room Footage') }}</div>
                                                </div>
                                            </div>
                                            <div class="item col-auto" v-if="room.beds_html">
                                                <div class="tooltip -top h-50">
                                                    <div class="tooltip__text">
                                                        <i class="input-icon field-icon icofont-hotel"></i>
                                                        <span v-html="room.beds_html"></span>
                                                    </div>
                                                    <div class="tooltip__content">{{ __('No. Beds') }}</div>
                                                </div>
                                            </div>
                                            <div class="item col-auto" v-if="room.adults_html">
                                                <div class="tooltip -top h-50">
                                                    <div class="tooltip__text">
                                                        <i class="input-icon field-icon icofont-users-alt-4"></i>
                                                        <span v-html="room.adults_html"></span>
                                                    </div>
                                                    <div class="tooltip__content">{{ __('No. Adults') }}</div>
                                                </div>
                                            </div>
                                            <div class="item col-auto" v-if="room.children_html">
                                                <div class="tooltip -top h-50">
                                                    <div class="tooltip__text">
                                                        <i class="input-icon field-icon fa-child fa"></i>
                                                        <span v-html="room.children_html"></span>
                                                    </div>
                                                    <div class="tooltip__content">{{ __('No. Children') }}</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div v-if="room.suplimentaryOlteanu">
                                            <div class="room-attribute mt-10">
                                                {{-- king bed --}}
                                                <div class="d-flex items-center">
                                                    <svg fill="#000000" width="50px" height="50px"
                                                        viewBox="0 0 512 512"
                                                        v-for="svgs in room.suplimentaryOlteanu.double_bed"
                                                        class="ml-5" id="Layer_1"
                                                        enable-background="new 0 0 512 512"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <g>
                                                            <path
                                                                d="m496 320c0-13.1 0-239.28 0-248 0-8.836-7.164-16-16-16s-16 7.164-16 16v16h-416v-16c0-8.836-7.164-16-16-16s-16 7.164-16 16v248c-8.836 0-16 7.164-16 16v104c0 8.836 7.164 16 16 16h40c5.036 0 9.778-2.371 12.8-6.4l19.2-25.6h336l19.2 25.6c3.021 4.029 7.764 6.4 12.8 6.4h40c8.836 0 16-7.164 16-16v-104c0-8.836-7.164-16-16-16zm-32-71.39c-17.206-9.979-30.797-8.61-48-8.61v-32c0-26.467-21.533-48-48-48h-80c-12.284 0-23.501 4.644-32 12.261-8.499-7.617-19.716-12.261-32-12.261h-80c-26.467 0-48 21.533-48 48v32c-17.989 0-30.887-1.315-48 8.61v-128.61h416zm-336-8.61v-32c0-8.822 7.178-16 16-16h80c8.822 0 16 7.178 16 16v32zm144-32c0-8.822 7.178-16 16-16h80c8.822 0 16 7.178 16 16v32h-112zm-224 96c0-17.645 14.355-32 32-32h352c17.645 0 32 14.355 32 32v16h-416zm432 120h-16l-19.2-25.6c-3.021-4.029-7.764-6.4-12.8-6.4h-352c-5.036 0-9.778 2.371-12.8 6.4l-19.2 25.6h-16v-72h448z" />
                                                        </g>
                                                    </svg>
                                                </div>
                                                {{-- single bed --}}
                                                <div class="d-flex items-center">
                                                    <svg fill="#000000" width="48px" height="48px"
                                                        v-for="svgs in room.suplimentaryOlteanu.single_bed"
                                                        viewBox="0 0 512 512" class="ml-5" id="Layer_1"
                                                        enable-background="new 0 0 512 512"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <g>
                                                            <path
                                                                d="m496 320c0-15.581 0-282.497 0-296 0-8.836-7.163-16-16-16s-16 7.164-16 16v16h-416v-16c0-8.836-7.164-16-16-16s-16 7.164-16 16v296c-8.836 0-16 7.164-16 16v152c0 8.836 7.164 16 16 16h56c6.061 0 11.601-3.424 14.311-8.845l19.578-39.155h300.223l19.578 39.155c2.71 5.421 8.25 8.845 14.311 8.845h56c8.837 0 16-7.164 16-16v-152c-.001-8.836-7.164-16-16.001-16zm-32-91.833c-11.449-7.679-25.209-12.167-40-12.167h-56v-32c0-35.29-28.71-64-64-64h-96c-35.29 0-64 28.71-64 64v32h-56c-14.791 0-28.551 4.488-40 12.167v-156.167h416zm-128-12.167h-160v-32c0-17.645 14.355-32 32-32h96c17.645 0 32 14.355 32 32zm-288 72c0-22.056 17.944-40 40-40h336c22.056 0 40 17.944 40 40v32h-416zm432 184h-30.111l-19.578-39.155c-2.71-5.421-8.25-8.845-14.311-8.845h-320c-6.061 0-11.601 3.424-14.311 8.845l-19.578 39.155h-30.111v-120h448z" />
                                                        </g>
                                                    </svg>
                                                </div>
                                                {{-- sofa --}}
                                                <div class="d-flex items-center">
                                                    <svg fill="#000000" width="50px" height="50px" class="ml-5"
                                                        v-for="svgs in room.suplimentaryOlteanu.sofa"
                                                        viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
                                                        xmlns:xlink="http://www.w3.org/1999/xlink">
                                                        <path
                                                            d="M7 4C5.3550302 4 4 5.3550302 4 7L4 8.1816406C3.7749277 8.0988815 3.5394844 8.0375539 3.2871094 8.0136719L3.2851562 8.0136719L3.2832031 8.0136719C2.6956383 7.9593227 2.0975168 8.0789836 1.5742188 8.3613281C0.16654993 9.1184219 -0.29860155 10.832824 0.26367188 12.236328L1.9628906 16.486328C2.4842054 17.787329 3.6480233 18.703727 5 18.9375L5 21L7 21L7 19L17 19L17 21L19 21L19 18.935547C20.352474 18.701653 21.51686 17.786714 22.037109 16.484375L23.769531 12.214844L23.771484 12.212891C24.310637 10.863481 23.896019 9.2254763 22.582031 8.4355469C22.112992 8.1535386 21.573166 8 21.027344 8C20.669496 8 20.324639 8.0704493 20 8.1894531L20 7C20 5.3550302 18.64497 4 17 4L7 4 z M 7 6L17 6C17.56503 6 18 6.4349698 18 7L18 10.474609L16.972656 13L7.03125 13L6 10.421875L6 7C6 6.4349698 6.4349698 6 7 6 z M 21.027344 10C21.211522 10 21.377821 10.044449 21.550781 10.148438C21.946794 10.386508 22.114863 10.96816 21.914062 11.470703L20.179688 15.740234L20.179688 15.742188C19.875347 16.503993 19.143398 17 18.322266 17L5.6777344 17C4.8584657 17 4.125776 16.504733 3.8203125 15.744141L3.8203125 15.742188L2.1210938 11.494141L2.1210938 11.492188C1.9097193 10.964664 2.0972168 10.35068 2.5214844 10.123047L2.5234375 10.121094C2.7075381 10.021764 2.8861235 9.9846829 3.0976562 10.003906C3.4440291 10.036686 3.8135404 10.336585 3.984375 10.763672L5.6777344 15L18.318359 15L20.09375 10.634766L20.095703 10.630859C20.248971 10.247062 20.61453 10 21.027344 10 z" />
                                                    </svg>
                                                </div>
                                            </div>
                                            {{-- <div class="d-flex items-center" v-for="term_child in room.term_features">
                                                 <i class="input-icon field-icon text-20 mr-10"
                                                    v-bind:class="term_child.icon"></i>
                                                <div class="text-15">@{{ term_child.title }}</div>
                                            </div> --}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="text-center" v-for="child in children" v-if="room.childrenPrices.length">
                                    Selecteaza varsta copilului
                                    <select v-if="room.childrenPrices" v-model="childrenPrices"
                                        :key="room.id + 'roomchildren'" name="childrenPrices[]"
                                        class="custom-select form-select rounded-4 border-light px-15 h-50 text-14">
                                        <option v-for="chPrice in room.childrenPrices" :value="chPrice.price">
                                            @{{ chPrice.minimum_age }} - @{{ chPrice.maximum_age }} ani
                                            @{{ chPrice.price == 0 || chPrice.price === '0' ? 'gratuit' : formatMoney(chPrice.price) }}
                                        </option>
                                    </select>
                                </div>
                                {{-- <div class="text-center">
                                    Doriti mic dejun (+100$)
                                    <select
                                        class="custom-select form-select rounded-4 border-light px-15 h-50 text-14">
                                        <option>
                                            Da
                                        </option>
                                        <option>
                                            Nu
                                        </option>
                                    </select>
                                </div> --}}
                                <div class="text-center"
                                    v-if="room.suplimentaryOlteanu && room.suplimentaryOlteanu.additional_bed_active">
                                    Doriti pat suplimentar? (<span
                                        v-html="formatMoney(room.suplimentaryOlteanu.additional_bed_price)"></span>)
                                    <select v-model="additional_bed"
                                        class="custom-select form-select rounded-4 border-light px-15 h-50 text-14">
                                        <option v-bind:value="room.suplimentaryOlteanu.additional_bed_price">
                                            Da
                                        </option>
                                        <option value="false">
                                            Nu
                                        </option>
                                    </select>
                                </div>
                                <div class="text-center">
                                    <span class="price" v-html="room.price_html"></span>
                                </div>
                                <select v-if="room.number" v-model="room.number_selected"
                                    class="custom-select form-select rounded-4 border-light px-15 h-50 text-14">
                                    <option value="0">0</option>
                                    <option v-for="i in (1,room.number)" :value="i">@{{ i + ' ' + (i > 1 ? i18n.rooms : i18n.room) }}
                                        &nbsp;&nbsp; (@{{ formatMoney(i * room.price) }})</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="hotel_room_book_status" v-if="total_price">
        <div class="row row_extra_service" v-if="extra_price.length">
            <div class="col-md-12">
                <div class="form-section-group">
                    <label>{{ __('Extra prices:') }}</label>
                    <div class="row">
                        <div class="col-md-6 extra-item" v-for="(type,index) in extra_price">
                            <div class="extra-price-wrap d-flex align-items-center justify-content-between">
                                <div class="flex-grow-1">
                                    <label class="d-flex items-center">
                                        <span class="form-checkbox ">
                                            <input type="checkbox" true-value="1" false-value="0" class="has-value"
                                                style="display: none;" v-model="type.enable">
                                            <span class="form-checkbox__mark"><span
                                                    class="form-checkbox__icon icon-check"></span></span>
                                        </span>
                                        <span class="text-15 ml-10"
                                            style="line-height: 1">@{{ type.name }}</span>
                                        <div class="render" v-if="type.price_type">(@{{ type.price_type }})</div>
                                    </label>
                                </div>
                                <div class="flex-shrink-0">@{{ type.price_html }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row row_total_price">
            <div class="col-md-6" style="border-right: 1px solid #ccc">
                <div class="extra-price-wrap d-flex justify-content-between">
                    <div class="flex-grow-1">
                        <label>
                            {{ __('Total Room') }}:
                        </label>
                    </div>
                    <div class="flex-shrink-0">
                        @{{ total_rooms }}
                    </div>
                </div>
                <div class="extra-price-wrap d-flex justify-content-between" v-for="(type,index) in buyer_fees">
                    <div class="flex-grow-1">
                        <label>
                            @{{ type.type_name }}
                            <span class="render" v-if="type.price_type">(@{{ type.price_type }})</span>
                            <div class="tooltip -top d-inline-block" v-if="type.desc">
                                <div class="tooltip__text"><i class="input-icon field-icon icofont-info-circle"></i>
                                </div>
                                <div class="tooltip__content"
                                    style="width: 230px; left: 50%; transform: translateX(-50%);">
                                    @{{ type.type_desc }}</div>
                            </div>
                        </label>
                    </div>
                    <div class="flex-shrink-0">
                        <div class="unit" v-if='type.unit == "percent"'>
                            @{{ type.price }}%
                        </div>
                        <div class="unit" v-else>
                            @{{ formatMoney(type.price) }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="control-book text-right">
                    <div class="total-room-price">
                        <span> {{ __('Total Price') }}:</span> @{{ total_price_html }}
                    </div>
                    <div v-if="is_deposit_ready" class="total-room-price font-weight-bold">
                        <span>{{ __('Pay now') }}</span>
                        @{{ pay_now_price_html }}
                    </div>
                    <button type="button"
                        class="button -dark-1 py-15 px-35 rounded-4 bg-blue-1 text-white cursor-pointer d-inline-block"
                        @click="doSubmit($event)" :class="{ 'disabled': onSubmit }" name="submit">
                        <span>{{ __('Book Now') }}</span>
                        <i v-show="onSubmit" class="fa fa-spinner fa-spin"></i>
                    </button>
                </div>

            </div>
        </div>
    </div>
    <div class="end_room_sticky"></div>
    <div class="alert alert-warning" v-if="!firstLoad && !rooms.length">
        {{ __('No room available with your selected date. Please change your search critical') }}
    </div>
</div>
