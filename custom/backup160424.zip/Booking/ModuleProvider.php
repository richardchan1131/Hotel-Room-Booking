<?php

namespace Custom\Booking;

class ModuleProvider extends \Modules\ModuleServiceProvider
{
    public function register()
    {
        
    }

    public function boot()
    {
        
    }
}
