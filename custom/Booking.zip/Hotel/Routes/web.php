<?php

use Custom\Hotel\App\Http\Controllers\VendorRoomController;
use \Illuminate\Support\Facades\Route;


// Route::group(['prefix' => 'user/' . config('hotel.hotel_route_prefix'), 'middleware' => ['auth', 'verified']], function () {
//     Route::group(['prefix' => 'room'], function () {
//         Route::get('{hotel_id}/edit/{id}', [VendorRoomController::class, 'edit'])->name('hotel.vendor.room.edit');
//     });
// });
